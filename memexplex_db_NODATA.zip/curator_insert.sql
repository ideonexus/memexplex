
LOCK TABLES `curator` WRITE;
/*!40000 ALTER TABLE `curator` DISABLE KEYS */;
INSERT INTO `curator` (`email`, `id`, `password`, `display_name`, `curator_level_id`, `publish_by_default`) VALUES 
('idea@mxplx.com', 2, '0c757723c6b5bd1f130082fc869f50660ed6edf4', 'idea', 6, 1);
/*!40000 ALTER TABLE `curator` ENABLE KEYS */;
UNLOCK TABLES;

