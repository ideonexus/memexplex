-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Mar 16, 2013 at 12:28 AM
-- Server version: 5.0.41
-- PHP Version: 5.2.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `memexplex_db`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `author`
-- 

CREATE TABLE IF NOT EXISTS `author` (
  `id` int(11) NOT NULL auto_increment,
  `last_name` varchar(125) NOT NULL,
  `first_name` varchar(125) NOT NULL,
  PRIMARY KEY  (`id`),
  FULLTEXT KEY `last_name` (`last_name`,`first_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1287 ;

-- --------------------------------------------------------

-- 
-- Table structure for table `curator`
-- 

CREATE TABLE IF NOT EXISTS `curator` (
  `email` varchar(256) NOT NULL,
  `id` int(11) NOT NULL auto_increment,
  `password` varchar(40) default NULL,
  `display_name` varchar(120) default NULL,
  `curator_level_id` tinyint(1) unsigned NOT NULL,
  `publish_by_default` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=999855149 ;

-- --------------------------------------------------------

-- 
-- Table structure for table `curator_level`
-- 

CREATE TABLE IF NOT EXISTS `curator_level` (
  `id` int(11) NOT NULL,
  `code` varchar(3) default NULL,
  `description` varchar(40) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

-- 
-- Table structure for table `meme`
-- 

CREATE TABLE IF NOT EXISTS `meme` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(250) NOT NULL,
  `text` varchar(10000) NOT NULL,
  `quote` varchar(10000) NOT NULL,
  `curator_id` int(11) NOT NULL,
  `published` tinyint(1) NOT NULL,
  `date_published` date NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY  (`id`),
  FULLTEXT KEY `text` (`text`),
  FULLTEXT KEY `quote` (`quote`),
  FULLTEXT KEY `text_search` (`title`,`text`,`quote`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2529 ;

-- --------------------------------------------------------

-- 
-- Table structure for table `meme_reference`
-- 

CREATE TABLE IF NOT EXISTS `meme_reference` (
  `reference_id` int(11) NOT NULL,
  `meme_id` int(11) NOT NULL,
  KEY `meme_id` (`meme_id`),
  KEY `reference_id` (`reference_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

-- 
-- Table structure for table `meme_taxonomy`
-- 

CREATE TABLE IF NOT EXISTS `meme_taxonomy` (
  `taxonomy_id` int(11) NOT NULL,
  `meme_id` int(11) NOT NULL,
  PRIMARY KEY  (`taxonomy_id`,`meme_id`),
  KEY `meme_id` (`meme_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

-- 
-- Table structure for table `predicate`
-- 

CREATE TABLE IF NOT EXISTS `predicate` (
  `id` int(11) NOT NULL auto_increment,
  `description` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

-- --------------------------------------------------------

-- 
-- Table structure for table `reference`
-- 

CREATE TABLE IF NOT EXISTS `reference` (
  `id` int(11) NOT NULL auto_increment,
  `reference_type_id` int(11) NOT NULL,
  `reference_date` text NOT NULL,
  `title` varchar(250) NOT NULL,
  `publication_location` varchar(250) NOT NULL,
  `publisher_periodical` varchar(250) NOT NULL,
  `volume_pages` varchar(250) NOT NULL,
  `url` varchar(4000) NOT NULL,
  `reference_service` varchar(250) NOT NULL,
  `date_retrieved` date NOT NULL,
  `curator_id` int(11) NOT NULL,
  `published` tinyint(1) NOT NULL,
  `date_published` date NOT NULL,
  `date` datetime NOT NULL,
  `isbn` char(10) NOT NULL,
  `ean` char(13) NOT NULL,
  `upc` char(12) NOT NULL,
  `large_image_url` varchar(2500) NOT NULL,
  `small_image_url` varchar(2500) NOT NULL,
  `asin` varchar(100) NOT NULL,
  `amazon_url` varchar(2500) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `title_2` (`title`),
  FULLTEXT KEY `title` (`title`),
  FULLTEXT KEY `publisher_periodical` (`publisher_periodical`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1300 ;

-- --------------------------------------------------------

-- 
-- Table structure for table `reference_author`
-- 

CREATE TABLE IF NOT EXISTS `reference_author` (
  `reference_id` int(11) NOT NULL,
  `author_id` int(11) NOT NULL,
  PRIMARY KEY  (`reference_id`,`author_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

-- 
-- Table structure for table `reference_parent_child`
-- 

CREATE TABLE IF NOT EXISTS `reference_parent_child` (
  `parent_id` int(11) NOT NULL,
  `child_id` int(11) NOT NULL,
  PRIMARY KEY  (`parent_id`,`child_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

-- 
-- Table structure for table `reference_super_type`
-- 

CREATE TABLE IF NOT EXISTS `reference_super_type` (
  `id` int(11) NOT NULL,
  `description` varchar(250) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

-- 
-- Table structure for table `reference_taxonomy`
-- 

CREATE TABLE IF NOT EXISTS `reference_taxonomy` (
  `taxonomy_id` int(11) NOT NULL,
  `reference_id` int(11) NOT NULL,
  PRIMARY KEY  (`taxonomy_id`,`reference_id`),
  KEY `reference_id` (`reference_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

-- 
-- Table structure for table `reference_type`
-- 

CREATE TABLE IF NOT EXISTS `reference_type` (
  `id` int(11) NOT NULL auto_increment,
  `reference_super_type_id` int(11) NOT NULL,
  `reference_type_description` varchar(250) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=108 ;


-- --------------------------------------------------------

-- 
-- Table structure for table `schema_map`
-- 

CREATE TABLE IF NOT EXISTS `schema_map` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(250) NOT NULL,
  `description` varchar(10000) NOT NULL,
  `curator_id` int(11) NOT NULL,
  `published` tinyint(1) NOT NULL,
  `date_published` date NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=63 ;

-- --------------------------------------------------------

-- 
-- Table structure for table `schema_meme`
-- 

CREATE TABLE IF NOT EXISTS `schema_meme` (
  `schema_id` int(11) NOT NULL,
  `meme_id` int(11) NOT NULL,
  PRIMARY KEY  (`schema_id`,`meme_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

-- 
-- Table structure for table `schema_parent_child`
-- 

CREATE TABLE IF NOT EXISTS `schema_parent_child` (
  `parent_id` int(11) NOT NULL,
  `child_id` int(11) NOT NULL,
  PRIMARY KEY  (`parent_id`,`child_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

-- 
-- Table structure for table `schema_taxonomy`
-- 

CREATE TABLE IF NOT EXISTS `schema_taxonomy` (
  `taxonomy_id` int(11) NOT NULL,
  `schema_id` int(11) NOT NULL,
  PRIMARY KEY  (`taxonomy_id`,`schema_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

-- 
-- Table structure for table `taxonomy`
-- 

CREATE TABLE IF NOT EXISTS `taxonomy` (
  `id` int(11) NOT NULL auto_increment,
  `text` varchar(80) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1791 ;

-- --------------------------------------------------------

-- 
-- Table structure for table `triple`
-- 

CREATE TABLE IF NOT EXISTS `triple` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(250) NOT NULL,
  `description` varchar(10000) NOT NULL,
  `subject_meme_id` int(11) NOT NULL,
  `predicate_id` int(11) NOT NULL,
  `object_meme_id` int(11) NOT NULL,
  `curator_id` int(11) NOT NULL,
  `published` tinyint(1) NOT NULL,
  `date_published` date NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=82 ;

-- --------------------------------------------------------

-- 
-- Table structure for table `triple_taxonomy`
-- 

CREATE TABLE IF NOT EXISTS `triple_taxonomy` (
  `taxonomy_id` int(11) NOT NULL,
  `triple_id` int(11) NOT NULL,
  PRIMARY KEY  (`taxonomy_id`,`triple_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

-- 
-- Dumping data for table `reference_super_type`
-- 

INSERT INTO `reference_super_type` (`id`, `description`) VALUES 
(1, 'Periodicals'),
(2, 'Books, Brochures, and Chapters'),
(3, 'Legal Materials'),
(4, 'Technical and Research Papers'),
(5, 'Proceedings of Meetings and Symposia'),
(6, 'Doctoral Dissertations and Master''s Theses'),
(7, 'Unpublished Work'),
(8, 'Reviews'),
(9, 'Audiovisual Media'),
(10, 'Electronic/World Wide Web'),
(11, 'Personal Communications');


-- 
-- Dumping data for table `reference_type`
-- 

INSERT INTO `reference_type` (`id`, `reference_super_type_id`, `reference_type_description`) VALUES 
(1, 1, 'Journal Article'),
(2, 1, 'Magazine Article'),
(6, 1, 'Newsletter Article'),
(7, 1, 'Newspaper Article'),
(9, 1, 'Journal Issue'),
(10, 1, 'Monograph'),
(11, 1, 'Abstract'),
(15, 2, 'Book'),
(19, 2, 'Encyclopedia'),
(20, 2, 'Dictionary'),
(23, 2, 'Brochure/Pamphlet'),
(25, 2, 'Book Chapter'),
(26, 2, 'Annual Periodical'),
(27, 3, 'Court Decision, U.S. Supreme'),
(28, 3, 'Court Decision, Lower Federal'),
(29, 3, 'Court Decision, State'),
(30, 3, 'Court Decision, Foreign'),
(31, 3, 'Statute, Federal'),
(32, 3, 'Statute, State'),
(33, 3, 'Statute, Foreign'),
(34, 3, 'Constitution, U.S.'),
(35, 3, 'Constitution, State'),
(36, 3, 'Constitution, Foreign'),
(37, 3, 'Congressional Hearing'),
(38, 3, 'Bill, Congressional'),
(39, 3, 'Bill, State'),
(40, 3, 'Bill, Foreign'),
(41, 3, 'Legislative Reports and Documents, Federal'),
(42, 3, 'Legislative Reports and Documents, State'),
(43, 4, 'Government Printing Office (GPO) Report'),
(44, 4, 'NTIS Report'),
(45, 4, 'ERIC Report'),
(46, 4, 'Government Report, Other'),
(47, 4, 'University Report'),
(48, 4, 'Private Organization Report'),
(49, 5, 'Unpublished Symposium Contribution'),
(50, 5, 'Unpublished Paper Presented at a Meeting'),
(51, 5, 'Poster Session'),
(52, 5, 'Speech'),
(53, 5, 'Conference Session'),
(54, 6, 'UMI Obtained DAI Doctoral Dissertation Abstract'),
(55, 6, 'University Obtained DAI Doctoral Dissertation Abstract'),
(56, 6, 'Doctoral Dissertation, Unpublished'),
(57, 6, 'Master''s Thesis, Unpublished'),
(58, 6, 'Doctoral Dissertation'),
(59, 6, 'Master''s Thesis'),
(60, 7, 'Unpublished Manuscript with a University Cited'),
(61, 7, 'Manuscript in Progress/Not Yet Accepted for Publication'),
(62, 7, 'Unpublished Raw Data from Study'),
(63, 7, 'Publication of Limited Circulation'),
(64, 8, 'Book Review'),
(65, 8, 'Motion Picture Review'),
(66, 8, 'Television Show Review'),
(67, 8, 'Album/Song Review'),
(68, 8, 'Performance Review'),
(69, 8, 'Website Review'),
(70, 8, 'Software Review'),
(71, 8, 'Game Review'),
(72, 9, 'Motion Picture'),
(73, 9, 'Television Broadcast'),
(74, 9, 'Television Series'),
(75, 9, 'Television Series, Single Episode'),
(76, 9, 'Music Recording'),
(77, 9, 'Audio Recording'),
(78, 9, 'Museum Exhibit'),
(79, 9, 'Live Performance'),
(80, 9, 'Photograph'),
(81, 9, 'Video Game'),
(82, 9, 'Software'),
(83, 10, 'Internet Article'),
(96, 10, 'Message Posted to a Newsgroup'),
(97, 10, 'Message Posted to Online Forum/Discussion Group'),
(98, 10, 'Message Posted to Electronic Mailing List'),
(99, 10, 'Wiki'),
(100, 10, 'Internet Video'),
(101, 10, 'Power Point Presentation'),
(102, 10, 'Blog'),
(103, 11, 'Email'),
(104, 11, 'Interview'),
(105, 11, 'Chat Room'),
(106, 11, 'Personal Letter'),
(107, 11, 'Phone Conversation');

LOCK TABLES `curator_level` WRITE;
/*!40000 ALTER TABLE `curator_level` DISABLE KEYS */;
INSERT INTO `curator_level` VALUES (0,'NON','Unverified'),(1,'ELF','Extremely Low Frequency'),(2,'SLF','Super Low Frequency'),(3,'VF','Voice Frequency'),(4,'VLF','Very Low Frequency'),(5,'LF','Low Frequency'),(6,'MF','Medium Frequency'),(7,'HF','High Frequency'),(8,'VHF','Very High Frequency'),(9,'UHF','Ultra High Frequency'),(10,'SHF','Super High Frequency'),(11,'EHF','Extremely High Frequency'),(12,'FIR','Far Infrared'),(13,'MIR','Mid Infrared'),(14,'NIR','Near Infrared'),(15,'NUV','Near Ultraviolet'),(16,'EUV','Extreme Ultraviolet'),(17,'SX','Soft X-rays'),(18,'HX','Hard X-rays'),(19,'Y','Gamma Rays'),(20,'AO','Alpha and Omega');
/*!40000 ALTER TABLE `curator_level` ENABLE KEYS */;
UNLOCK TABLES;

