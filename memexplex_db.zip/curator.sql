-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Mar 16, 2013 at 12:43 AM
-- Server version: 5.0.41
-- PHP Version: 5.2.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `memexplex_db`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `curator`
-- 

CREATE TABLE IF NOT EXISTS `curator` (
  `email` varchar(256) NOT NULL,
  `id` int(11) NOT NULL auto_increment,
  `password` varchar(40) default NULL,
  `display_name` varchar(120) default NULL,
  `curator_level_id` tinyint(1) unsigned NOT NULL,
  `publish_by_default` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=999855149 ;

-- 
-- Dumping data for table `curator`
-- 

INSERT INTO `curator` (`email`, `id`, `password`, `display_name`, `curator_level_id`, `publish_by_default`) VALUES 
('idea@mxplx.com', 2, '0c757723c6b5bd1f130082fc869f50660ed6edf4', 'idea', 6, 1);
